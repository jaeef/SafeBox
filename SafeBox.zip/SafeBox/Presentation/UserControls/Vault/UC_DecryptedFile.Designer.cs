namespace SafeBox.Presentation.UserControls.Vault
{
    partial class UC_DecryptedFile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_DecryptedFile));
            this.cuiPanel1 = new CuoreUI.Controls.cuiPanel();
            this.cuiLabel1 = new CuoreUI.Controls.cuiLabel();
            this.cuiPanel3 = new CuoreUI.Controls.cuiPanel();
            this.dropZonePanel = new CuoreUI.Controls.cuiFileDropper();
            this.cuiPanel1.SuspendLayout();
            this.cuiPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cuiPanel1
            // 
            this.cuiPanel1.Controls.Add(this.cuiLabel1);
            this.cuiPanel1.Controls.Add(this.cuiPanel3);
            this.cuiPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cuiPanel1.Location = new System.Drawing.Point(0, 0);
            this.cuiPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.cuiPanel1.Name = "cuiPanel1";
            this.cuiPanel1.OutlineThickness = 1F;
            this.cuiPanel1.PanelColor = System.Drawing.Color.White;
            this.cuiPanel1.PanelOutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cuiPanel1.Rounding = new System.Windows.Forms.Padding(8);
            this.cuiPanel1.Size = new System.Drawing.Size(766, 473);
            this.cuiPanel1.TabIndex = 17;
            this.cuiPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.cuiPanel1_Paint);
            // 
            // cuiLabel1
            // 
            this.cuiLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.cuiLabel1.Content = "Decrypt\\ your\\ Files";
            this.cuiLabel1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cuiLabel1.ForeColor = System.Drawing.Color.OrangeRed;
            this.cuiLabel1.HorizontalAlignment = System.Drawing.StringAlignment.Center;
            this.cuiLabel1.Location = new System.Drawing.Point(40, 14);
            this.cuiLabel1.Name = "cuiLabel1";
            this.cuiLabel1.Size = new System.Drawing.Size(208, 35);
            this.cuiLabel1.TabIndex = 0;
            this.cuiLabel1.VerticalAlignment = System.Drawing.StringAlignment.Near;
            // 
            // cuiPanel3
            // 
            this.cuiPanel3.Controls.Add(this.dropZonePanel);
            this.cuiPanel3.Location = new System.Drawing.Point(3, 88);
            this.cuiPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.cuiPanel3.Name = "cuiPanel3";
            this.cuiPanel3.OutlineThickness = 1F;
            this.cuiPanel3.PanelColor = System.Drawing.Color.White;
            this.cuiPanel3.PanelOutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cuiPanel3.Rounding = new System.Windows.Forms.Padding(8);
            this.cuiPanel3.Size = new System.Drawing.Size(761, 383);
            this.cuiPanel3.TabIndex = 3;
            // 
            // dropZonePanel
            // 
            this.dropZonePanel.AllowDrop = true;
            this.dropZonePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dropZonePanel.DashedOutline = true;
            this.dropZonePanel.DashedOutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dropZonePanel.DashLength = 8;
            this.dropZonePanel.Filter = "";
            this.dropZonePanel.ForeColor = System.Drawing.Color.Gray;
            this.dropZonePanel.HoverContent = "Release to drop";
            this.dropZonePanel.HoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dropZonePanel.HoverUploadForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.dropZonePanel.Image = ((System.Drawing.Image)(resources.GetObject("dropZonePanel.Image")));
            this.dropZonePanel.ImagePadding = 2;
            this.dropZonePanel.ImageSize = new System.Drawing.Size(24, 24);
            this.dropZonePanel.ImageTint = System.Drawing.Color.Gray;
            this.dropZonePanel.Location = new System.Drawing.Point(68, 29);
            this.dropZonePanel.Multiselect = false;
            this.dropZonePanel.Name = "dropZonePanel";
            this.dropZonePanel.NormalContent = "Drop Encripted file";
            this.dropZonePanel.NormalForeColor = System.Drawing.Color.Gray;
            this.dropZonePanel.NormalUploadForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.dropZonePanel.OutlineThickness = 1F;
            this.dropZonePanel.PanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dropZonePanel.Rounding = new System.Windows.Forms.Padding(8);
            this.dropZonePanel.Size = new System.Drawing.Size(622, 304);
            this.dropZonePanel.TabIndex = 4;
            this.dropZonePanel.Text = "cuiFileDropper1";
            this.dropZonePanel.UploadContent = "Click to upload";
            this.dropZonePanel.UploadWithClick = true;
            // 
            // UC_DecryptedFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cuiPanel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UC_DecryptedFile";
            this.Size = new System.Drawing.Size(766, 473);
            this.cuiPanel1.ResumeLayout(false);
            this.cuiPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private CuoreUI.Controls.cuiPanel cuiPanel1;
        private CuoreUI.Controls.cuiLabel cuiLabel1;
        private CuoreUI.Controls.cuiPanel cuiPanel3;
        private CuoreUI.Controls.cuiFileDropper dropZonePanel;
    }
}
