namespace SafeBox.Presentation.UserControls.Vault
{
    partial class UC_VaultContent
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_VaultContent));
            this.materialCard2 = new ReaLTaiizor.Controls.MaterialCard();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnBack = new CuoreUI.Controls.cuiButton();
            this.btnUpload = new CuoreUI.Controls.cuiButton();
            this.lblVaultName = new CuoreUI.Controls.cuiLabel();
            this.dropZonePanel = new CuoreUI.Controls.cuiFileDropper();
            this.materialCard1 = new ReaLTaiizor.Controls.MaterialCard();
            this.btnDecrypt = new CuoreUI.Controls.cuiButton();
            this.materialCard2.SuspendLayout();
            this.materialCard1.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialCard2
            // 
            this.materialCard2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard2.Controls.Add(this.flowLayoutPanel1);
            this.materialCard2.Depth = 0;
            this.materialCard2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard2.Location = new System.Drawing.Point(0, 228);
            this.materialCard2.Margin = new System.Windows.Forms.Padding(19, 17, 19, 17);
            this.materialCard2.MouseState = ReaLTaiizor.Helper.MaterialDrawHelper.MaterialMouseState.HOVER;
            this.materialCard2.Name = "materialCard2";
            this.materialCard2.Padding = new System.Windows.Forms.Padding(19, 17, 19, 17);
            this.materialCard2.Size = new System.Drawing.Size(1252, 602);
            this.materialCard2.TabIndex = 3;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(19, 17);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1214, 568);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.CheckButton = false;
            this.btnBack.Checked = false;
            this.btnBack.CheckedBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnBack.CheckedForeColor = System.Drawing.Color.Gray;
            this.btnBack.CheckedImageTint = System.Drawing.Color.Gray;
            this.btnBack.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnBack.Content = "Back ";
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBack.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.Black;
            this.btnBack.HoverBackground = System.Drawing.Color.RosyBrown;
            this.btnBack.HoverForeColor = System.Drawing.Color.Black;
            this.btnBack.HoverImageTint = System.Drawing.Color.RosyBrown;
            this.btnBack.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.Image = null;
            this.btnBack.ImageAutoCenter = true;
            this.btnBack.ImageExpand = new System.Drawing.Point(0, 0);
            this.btnBack.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnBack.Location = new System.Drawing.Point(17, 9);
            this.btnBack.Margin = new System.Windows.Forms.Padding(0);
            this.btnBack.Name = "btnBack";
            this.btnBack.NormalBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnBack.NormalForeColor = System.Drawing.Color.Black;
            this.btnBack.NormalImageTint = System.Drawing.Color.White;
            this.btnBack.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.OutlineThickness = 1F;
            this.btnBack.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.btnBack.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnBack.PressedImageTint = System.Drawing.Color.White;
            this.btnBack.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.Rounding = new System.Windows.Forms.Padding(5);
            this.btnBack.Size = new System.Drawing.Size(111, 39);
            this.btnBack.TabIndex = 57;
            this.btnBack.TextAlignment = System.Drawing.StringAlignment.Center;
            this.btnBack.TextOffset = new System.Drawing.Point(0, 0);
            // 
            // btnUpload
            // 
            this.btnUpload.CheckButton = false;
            this.btnUpload.Checked = false;
            this.btnUpload.CheckedBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnUpload.CheckedForeColor = System.Drawing.Color.DimGray;
            this.btnUpload.CheckedImageTint = System.Drawing.Color.DimGray;
            this.btnUpload.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnUpload.Content = "+ Upload Files";
            this.btnUpload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpload.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUpload.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.Color.Black;
            this.btnUpload.HoverBackground = System.Drawing.Color.IndianRed;
            this.btnUpload.HoverForeColor = System.Drawing.Color.Black;
            this.btnUpload.HoverImageTint = System.Drawing.Color.IndianRed;
            this.btnUpload.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnUpload.Image = null;
            this.btnUpload.ImageAutoCenter = true;
            this.btnUpload.ImageExpand = new System.Drawing.Point(0, 0);
            this.btnUpload.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnUpload.Location = new System.Drawing.Point(1055, 9);
            this.btnUpload.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.NormalBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnUpload.NormalForeColor = System.Drawing.Color.Black;
            this.btnUpload.NormalImageTint = System.Drawing.Color.White;
            this.btnUpload.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnUpload.OutlineThickness = 1F;
            this.btnUpload.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.btnUpload.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnUpload.PressedImageTint = System.Drawing.Color.White;
            this.btnUpload.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnUpload.Rounding = new System.Windows.Forms.Padding(8);
            this.btnUpload.Size = new System.Drawing.Size(185, 65);
            this.btnUpload.TabIndex = 59;
            this.btnUpload.TextAlignment = System.Drawing.StringAlignment.Center;
            this.btnUpload.TextOffset = new System.Drawing.Point(0, 0);
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click_1);
            // 
            // lblVaultName
            // 
            this.lblVaultName.BackColor = System.Drawing.Color.Transparent;
            this.lblVaultName.Content = "Vault\\ Name";
            this.lblVaultName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVaultName.HorizontalAlignment = System.Drawing.StringAlignment.Near;
            this.lblVaultName.Location = new System.Drawing.Point(23, 52);
            this.lblVaultName.Margin = new System.Windows.Forms.Padding(5);
            this.lblVaultName.Name = "lblVaultName";
            this.lblVaultName.Size = new System.Drawing.Size(151, 36);
            this.lblVaultName.TabIndex = 60;
            this.lblVaultName.VerticalAlignment = System.Drawing.StringAlignment.Center;
            // 
            // dropZonePanel
            // 
            this.dropZonePanel.AllowDrop = true;
            this.dropZonePanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dropZonePanel.DashedOutline = true;
            this.dropZonePanel.DashedOutlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dropZonePanel.DashLength = 8;
            this.dropZonePanel.Filter = "";
            this.dropZonePanel.ForeColor = System.Drawing.Color.Gray;
            this.dropZonePanel.HoverContent = "Release to drop";
            this.dropZonePanel.HoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dropZonePanel.HoverUploadForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.dropZonePanel.Image = ((System.Drawing.Image)(resources.GetObject("dropZonePanel.Image")));
            this.dropZonePanel.ImagePadding = 2;
            this.dropZonePanel.ImageSize = new System.Drawing.Size(24, 24);
            this.dropZonePanel.ImageTint = System.Drawing.Color.Gray;
            this.dropZonePanel.Location = new System.Drawing.Point(0, 0);
            this.dropZonePanel.Margin = new System.Windows.Forms.Padding(4);
            this.dropZonePanel.Multiselect = false;
            this.dropZonePanel.Name = "dropZonePanel";
            this.dropZonePanel.NormalContent = "Drop file here";
            this.dropZonePanel.NormalForeColor = System.Drawing.Color.Gray;
            this.dropZonePanel.NormalUploadForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.dropZonePanel.OutlineThickness = 1F;
            this.dropZonePanel.PanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dropZonePanel.Rounding = new System.Windows.Forms.Padding(8);
            this.dropZonePanel.Size = new System.Drawing.Size(1248, 111);
            this.dropZonePanel.TabIndex = 0;
            this.dropZonePanel.Text = "cuiFileDropper1";
            this.dropZonePanel.UploadContent = "Click to upload";
            this.dropZonePanel.UploadWithClick = true;
            this.dropZonePanel.FileDropped += new System.EventHandler<CuoreUI.Controls.FileDroppedEventArgs>(this.dropZonePanel_FileDropped);
            // 
            // materialCard1
            // 
            this.materialCard1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialCard1.Controls.Add(this.dropZonePanel);
            this.materialCard1.Depth = 0;
            this.materialCard1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialCard1.Location = new System.Drawing.Point(1, 96);
            this.materialCard1.Margin = new System.Windows.Forms.Padding(19, 17, 19, 17);
            this.materialCard1.MouseState = ReaLTaiizor.Helper.MaterialDrawHelper.MaterialMouseState.HOVER;
            this.materialCard1.Name = "materialCard1";
            this.materialCard1.Padding = new System.Windows.Forms.Padding(19, 17, 19, 17);
            this.materialCard1.Size = new System.Drawing.Size(1252, 116);
            this.materialCard1.TabIndex = 2;
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.CheckButton = false;
            this.btnDecrypt.Checked = false;
            this.btnDecrypt.CheckedBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnDecrypt.CheckedForeColor = System.Drawing.Color.DimGray;
            this.btnDecrypt.CheckedImageTint = System.Drawing.Color.DimGray;
            this.btnDecrypt.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnDecrypt.Content = "Decrypt Files";
            this.btnDecrypt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDecrypt.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnDecrypt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecrypt.ForeColor = System.Drawing.Color.Black;
            this.btnDecrypt.HoverBackground = System.Drawing.Color.IndianRed;
            this.btnDecrypt.HoverForeColor = System.Drawing.Color.Black;
            this.btnDecrypt.HoverImageTint = System.Drawing.Color.IndianRed;
            this.btnDecrypt.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDecrypt.Image = null;
            this.btnDecrypt.ImageAutoCenter = true;
            this.btnDecrypt.ImageExpand = new System.Drawing.Point(0, 0);
            this.btnDecrypt.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnDecrypt.Location = new System.Drawing.Point(853, 9);
            this.btnDecrypt.Margin = new System.Windows.Forms.Padding(4);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.NormalBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnDecrypt.NormalForeColor = System.Drawing.Color.Black;
            this.btnDecrypt.NormalImageTint = System.Drawing.Color.White;
            this.btnDecrypt.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDecrypt.OutlineThickness = 1F;
            this.btnDecrypt.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.btnDecrypt.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnDecrypt.PressedImageTint = System.Drawing.Color.White;
            this.btnDecrypt.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDecrypt.Rounding = new System.Windows.Forms.Padding(8);
            this.btnDecrypt.Size = new System.Drawing.Size(185, 65);
            this.btnDecrypt.TabIndex = 61;
            this.btnDecrypt.TextAlignment = System.Drawing.StringAlignment.Center;
            this.btnDecrypt.TextOffset = new System.Drawing.Point(0, 0);
            // 
            // UC_VaultContent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.lblVaultName);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.materialCard2);
            this.Controls.Add(this.materialCard1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UC_VaultContent";
            this.Size = new System.Drawing.Size(1252, 818);
            this.materialCard2.ResumeLayout(false);
            this.materialCard1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private ReaLTaiizor.Controls.MaterialCard materialCard2;
        private CuoreUI.Controls.cuiButton btnBack;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private CuoreUI.Controls.cuiButton btnUpload;
        private CuoreUI.Controls.cuiLabel lblVaultName;
        private CuoreUI.Controls.cuiFileDropper dropZonePanel;
        private ReaLTaiizor.Controls.MaterialCard materialCard1;
        private CuoreUI.Controls.cuiButton btnDecrypt;
    }
}

