using System;
using System.IO;
using System.Windows.Forms;
using SafeBox.Application.Interfaces;
using SafeBox.Infrastructure.Services;

namespace SafeBox.Presentation.UserControls.Vault
{
    public partial class UC_DecryptedFile : UserControl
    {
        private readonly IVaultService _vaultService;
        private readonly IEncryptionService _encryptionService;

        public UC_DecryptedFile()
        {
            InitializeComponent();
            _encryptionService = new EncryptionService();
        }

        public UC_DecryptedFile(IVaultService vaultService) : this()
        {
            _vaultService = vaultService;
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Title = "Select Your Encrypted SafeBox File";
                    openFileDialog.Filter = "SafeBox Encrypted (*.txt;*.bin)|*.txt;*.bin|All Files (*.*)|*.*";

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        byte[] encryptedData;
                        string filePath = openFileDialog.FileName;

                        // Check if file is Base64 encoded (typical for our .txt downloads)
                        string content = File.ReadAllText(filePath);
                        try
                        {
                            encryptedData = Convert.FromBase64String(content);
                        }
                        catch
                        {
                            // If not base64, read as raw bytes
                            encryptedData = File.ReadAllBytes(filePath);
                        }

                        // Decrypt using the system encryption service
                        byte[] decryptedData = _encryptionService.Decrypt(encryptedData);

                        using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                        {
                            string originalFileName = Path.GetFileNameWithoutExtension(filePath);
                            saveFileDialog.FileName = originalFileName;
                            saveFileDialog.Title = "Save Decrypted File";
                            saveFileDialog.Filter = "All Files (*.*)|*.*";

                            if (saveFileDialog.ShowDialog() == DialogResult.OK)
                            {
                                File.WriteAllBytes(saveFileDialog.FileName, decryptedData);
                                MessageBox.Show("File decrypted and saved successfully!", "Success", 
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Decryption failed: {ex.Message}\n\nPlease ensure you uploaded a valid SafeBox encrypted file.", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cuiPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
