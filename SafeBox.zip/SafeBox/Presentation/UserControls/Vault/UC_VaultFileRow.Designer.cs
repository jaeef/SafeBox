namespace SafeBox.Presentation.UserControls.Vault
{
    partial class UC_VaultFileRow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_VaultFileRow));
            this.btnDelete = new CuoreUI.Controls.cuiButton();
            this.btnDownload = new CuoreUI.Controls.cuiButton();
            this.lblFileName = new CuoreUI.Controls.cuiLabel();
            this.lblFileType = new CuoreUI.Controls.cuiLabel();
            this.cuiButton1 = new CuoreUI.Controls.cuiButton();
            this.lblVault = new CuoreUI.Controls.cuiLabel();
            this.lblSize = new CuoreUI.Controls.cuiLabel();
            this.lblDate = new CuoreUI.Controls.cuiLabel();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.CheckButton = false;
            this.btnDelete.Checked = false;
            this.btnDelete.CheckedBackground = System.Drawing.Color.Transparent;
            this.btnDelete.CheckedForeColor = System.Drawing.Color.White;
            this.btnDelete.CheckedImageTint = System.Drawing.Color.White;
            this.btnDelete.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnDelete.Content = "";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDelete.HoverBackground = System.Drawing.Color.DarkRed;
            this.btnDelete.HoverForeColor = System.Drawing.Color.Black;
            this.btnDelete.HoverImageTint = System.Drawing.Color.Transparent;
            this.btnDelete.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAutoCenter = true;
            this.btnDelete.ImageExpand = new System.Drawing.Point(10, 10);
            this.btnDelete.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnDelete.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.btnDelete.Location = new System.Drawing.Point(1059, 16);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.NormalBackground = System.Drawing.Color.Transparent;
            this.btnDelete.NormalForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDelete.NormalImageTint = System.Drawing.Color.White;
            this.btnDelete.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDelete.OutlineThickness = 1F;
            this.btnDelete.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.btnDelete.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.btnDelete.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnDelete.PressedImageTint = System.Drawing.Color.White;
            this.btnDelete.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnDelete.Rounding = new System.Windows.Forms.Padding(1);
            this.btnDelete.Size = new System.Drawing.Size(80, 54);
            this.btnDelete.TabIndex = 31;
            this.btnDelete.TextAlignment = System.Drawing.StringAlignment.Far;
            this.btnDelete.TextOffset = new System.Drawing.Point(-40, 0);
            // 
            // btnDownload
            // 
            this.btnDownload.CheckButton = false;
            this.btnDownload.Checked = false;
            this.btnDownload.CheckedBackground = System.Drawing.Color.Transparent;
            this.btnDownload.CheckedForeColor = System.Drawing.Color.White;
            this.btnDownload.CheckedImageTint = System.Drawing.Color.White;
            this.btnDownload.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.btnDownload.Content = "";
            this.btnDownload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDownload.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnDownload.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownload.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDownload.HoverBackground = System.Drawing.Color.RoyalBlue;
            this.btnDownload.HoverForeColor = System.Drawing.Color.Black;
            this.btnDownload.HoverImageTint = System.Drawing.Color.Transparent;
            this.btnDownload.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDownload.Image = ((System.Drawing.Image)(resources.GetObject("btnDownload.Image")));
            this.btnDownload.ImageAutoCenter = true;
            this.btnDownload.ImageExpand = new System.Drawing.Point(10, 10);
            this.btnDownload.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnDownload.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.btnDownload.Location = new System.Drawing.Point(972, 16);
            this.btnDownload.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.NormalBackground = System.Drawing.Color.Transparent;
            this.btnDownload.NormalForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDownload.NormalImageTint = System.Drawing.Color.White;
            this.btnDownload.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDownload.OutlineThickness = 1F;
            this.btnDownload.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.btnDownload.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.btnDownload.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.btnDownload.PressedImageTint = System.Drawing.Color.White;
            this.btnDownload.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnDownload.Rounding = new System.Windows.Forms.Padding(1);
            this.btnDownload.Size = new System.Drawing.Size(79, 54);
            this.btnDownload.TabIndex = 32;
            this.btnDownload.TextAlignment = System.Drawing.StringAlignment.Far;
            this.btnDownload.TextOffset = new System.Drawing.Point(-40, 0);
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click_1);
            // 
            // lblFileName
            // 
            this.lblFileName.Content = "Your\\ text\\ here!";
            this.lblFileName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileName.HorizontalAlignment = System.Drawing.StringAlignment.Near;
            this.lblFileName.Location = new System.Drawing.Point(64, 16);
            this.lblFileName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(384, 23);
            this.lblFileName.TabIndex = 33;
            this.lblFileName.VerticalAlignment = System.Drawing.StringAlignment.Near;
            // 
            // lblFileType
            // 
            this.lblFileType.Content = "Your\\ text\\ here!";
            this.lblFileType.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileType.HorizontalAlignment = System.Drawing.StringAlignment.Near;
            this.lblFileType.Location = new System.Drawing.Point(67, 47);
            this.lblFileType.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lblFileType.Name = "lblFileType";
            this.lblFileType.Size = new System.Drawing.Size(381, 30);
            this.lblFileType.TabIndex = 34;
            this.lblFileType.VerticalAlignment = System.Drawing.StringAlignment.Center;
            // 
            // cuiButton1
            // 
            this.cuiButton1.CheckButton = false;
            this.cuiButton1.Checked = false;
            this.cuiButton1.CheckedBackground = System.Drawing.Color.Transparent;
            this.cuiButton1.CheckedForeColor = System.Drawing.Color.White;
            this.cuiButton1.CheckedImageTint = System.Drawing.Color.White;
            this.cuiButton1.CheckedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(106)))), ((int)(((byte)(0)))));
            this.cuiButton1.Content = "";
            this.cuiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cuiButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.cuiButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cuiButton1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cuiButton1.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.cuiButton1.HoverForeColor = System.Drawing.Color.Black;
            this.cuiButton1.HoverImageTint = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.cuiButton1.HoverOutline = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cuiButton1.Image = ((System.Drawing.Image)(resources.GetObject("cuiButton1.Image")));
            this.cuiButton1.ImageAutoCenter = true;
            this.cuiButton1.ImageExpand = new System.Drawing.Point(10, 10);
            this.cuiButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.cuiButton1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cuiButton1.Location = new System.Drawing.Point(4, 16);
            this.cuiButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cuiButton1.Name = "cuiButton1";
            this.cuiButton1.NormalBackground = System.Drawing.Color.Transparent;
            this.cuiButton1.NormalForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cuiButton1.NormalImageTint = System.Drawing.Color.White;
            this.cuiButton1.NormalOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.cuiButton1.OutlineThickness = 1F;
            this.cuiButton1.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.cuiButton1.PressedBackground = System.Drawing.Color.WhiteSmoke;
            this.cuiButton1.PressedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.cuiButton1.PressedImageTint = System.Drawing.Color.White;
            this.cuiButton1.PressedOutline = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cuiButton1.Rounding = new System.Windows.Forms.Padding(1);
            this.cuiButton1.Size = new System.Drawing.Size(55, 54);
            this.cuiButton1.TabIndex = 35;
            this.cuiButton1.TextAlignment = System.Drawing.StringAlignment.Far;
            this.cuiButton1.TextOffset = new System.Drawing.Point(-40, 0);
            // 
            // lblVault
            // 
            this.lblVault.BackColor = System.Drawing.Color.Transparent;
            this.lblVault.Content = "Your\\ text\\ here!";
            this.lblVault.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVault.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblVault.HorizontalAlignment = System.Drawing.StringAlignment.Center;
            this.lblVault.Location = new System.Drawing.Point(477, 2);
            this.lblVault.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lblVault.Name = "lblVault";
            this.lblVault.Size = new System.Drawing.Size(148, 73);
            this.lblVault.TabIndex = 36;
            this.lblVault.VerticalAlignment = System.Drawing.StringAlignment.Center;
            // 
            // lblSize
            // 
            this.lblSize.Content = "Your\\ text\\ here!";
            this.lblSize.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSize.HorizontalAlignment = System.Drawing.StringAlignment.Center;
            this.lblSize.Location = new System.Drawing.Point(645, 27);
            this.lblSize.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(132, 30);
            this.lblSize.TabIndex = 37;
            this.lblSize.VerticalAlignment = System.Drawing.StringAlignment.Center;
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Content = "Your\\ text\\ here!";
            this.lblDate.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.HorizontalAlignment = System.Drawing.StringAlignment.Center;
            this.lblDate.Location = new System.Drawing.Point(811, 27);
            this.lblDate.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(153, 30);
            this.lblDate.TabIndex = 38;
            this.lblDate.VerticalAlignment = System.Drawing.StringAlignment.Center;
            // 
            // UC_VaultFileRow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblSize);
            this.Controls.Add(this.lblVault);
            this.Controls.Add(this.cuiButton1);
            this.Controls.Add(this.lblFileType);
            this.Controls.Add(this.lblFileName);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.btnDelete);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UC_VaultFileRow";
            this.Size = new System.Drawing.Size(1147, 86);
            this.ResumeLayout(false);

        }

        #endregion

        private CuoreUI.Controls.cuiButton btnDelete;
        private CuoreUI.Controls.cuiButton btnDownload;
        private CuoreUI.Controls.cuiLabel lblFileName;
        private CuoreUI.Controls.cuiLabel lblFileType;
        private CuoreUI.Controls.cuiButton cuiButton1;
        private CuoreUI.Controls.cuiLabel lblVault;
        private CuoreUI.Controls.cuiLabel lblSize;
        private CuoreUI.Controls.cuiLabel lblDate;
    }
}
